local customEntities = require "necro.game.data.CustomEntities"
local components = require "necro.game.data.Components"
local ecs = require "system.game.Entities"
local itemBan = require "necro.game.item.ItemBan"
local object = require "necro.game.object.Object"
local settings = require "necro.config.Settings"
local inventory = require "necro.game.item.Inventory"

customEntities.extend {
    name="Lynda",
    template=customEntities.template.player(7),
    components = {
        {
            DynChar_dynamicCharacter = {
                slotMirrors = {},
                slotOffsets = {
                    action = { -0.5, 2, -0.5, 2, -0.5, 2, -0.5, 2 },
                    base = { -1, 4, -1, 4, -1, 4, -1, 4 },
                    body = { -0.5, 2, -0.5, 2, -0.5, 2, -0.5, 2 },
                    bomb = { -0.5, 2, -0.5, 2, -0.5, 2, -0.5, 2 },
                    feet = { -0.5, -1, -0.5, -1, -0.5, -1, -0.5, -1 },
                    head = { -0.5, -1, -0.5, 1, -0.5, 3, -0.5, 1 },
                    hud = { -0.5, 2, -0.5, 2, -0.5, 2, -0.5, 2 },
                    misc = { -0.5, 0, -0.5, 2, -0.5, 4, -0.5, 2 },
                    ring = { -0.5, 2, -0.5, 2, -0.5, 2, -0.5, 2 },
                    shovel = { -0.5, 2, -0.5, 2, -0.5, 2, -0.5, 2 },
                    spell = { -0.5, 2, -0.5, 2, -0.5, 2, -0.5, 2 },
                    torch = { -2.5, 2, -3.5, 2, -4.5, 1, -2.5, 1 },
                    weapon = { 1.5, 2, 3.5, 2, 4.5, 1, 2.5, 2 }
                }
            },
            friendlyName={name="Lynda"},
            CodaFlavors_menu={
                order = 40,
                explanation = "Coda with Lunging and Knockback"
            },
			textCharacterSelectionMessage = { text = "Lynda mode!\nLunging &\nKnockback." },
			playableCharacterUnlockable = false,
			playableCharacterUnlockOnRunCompletion = false,
			bestiary = {
                image = "mods/CodaFlavors/sprites/Lynda/LyndaBestiary.png",
            },
			sprite={
                texture= "mods/CodaFlavors/sprites/Lynda/LyndaBody.png",
            },
            cloneSprite = {
                texture = "mods/CodaFlavors/sprites/Lynda/LyndaClone.png",
            },
            enemyBans = {
                types = {},
            },
            initialEquipment={
                items={"ShovelBasic","CodaFlavors_FeetBootsLunging","Bomb","CharmNazar","CodaFlavors_WeaponLynda"},
            },
            inventoryCursedSlots = {
                slots = {
                    feet = true;
                }
            },
            inventoryBannedItemTypes = {
            },
            InGameAchievements_allZonesAchievement = {
                data = {
                    friendlyName = "Uncontrollable",
                    version = 1,
                    icon = "mods/CodaFlavors/sprites/Achievements/Lynda.png"
                },
            }
        },
		{
			sprite={
                texture= "mods/CodaFlavors/sprites/Lynda/LyndaHead.png",
            },
        },
    },
}